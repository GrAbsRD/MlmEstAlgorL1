% Solves the following basis pursuit denoising (BPDN) problem
% min_x  \tau ||x||_1 + 1/2*||b - Ax||_2^2
%
% Inputs:
% A - m x n measurement matrix
% y - measurement vector
% tau - final value of regularization parameter
% maxiter - maximum number of homotopy iterations
%
% Outputs:
% x - output for BPDN
% total_iter - number of homotopy iterations taken by the solver
% total_time - time taken by the solver
%
% Written by: Salman Asif, Georgia Tech
% Email: sasif@ece.gatech.edu
%
% Modified 
% November 2023: Simplified by zqfeng.
% 
%-----------------------------------------------------------+
% Copyright (c) 2007.  Muhammad Salman Asif
%-----------------------------------------------------------+

function [x, total_iter, total_time] = BP_homotopy(A, b, tau, maxiter)

        t0 = cputime;
        [~, n] = size(A);
        
        %% parameters
        if nargin < 4
                maxiter = 4 * n;
        elseif nargin < 3
                tau = 1;
        end
        % x0 = ones(n, 1);
        
        %% Initialization of primal and dual sign and support
        z_x = zeros(n, 1);
        % gamma_x = [];
        
        % Initial step
        pk_old = -A' * b;
        [epsilon, gamma_xk] = max(abs(pk_old));
        
        xk_1 = zeros(n, 1);
        z_x(gamma_xk) = -sign(pk_old(gamma_xk));
        pk_old(gamma_xk) = sign(pk_old(gamma_xk)) * epsilon;
        z_xk = z_x;
        
        % loop parameters
        iter = 0;
        % old_delta = 0;
        lambda_shk = [];
        AtransAg_x = A(:, gamma_xk)' * A(:, gamma_xk);
        iAtransAg_x = inv(AtransAg_x);
        
        G = @(z) A * z;
        Gtrans = @(z) A' * z;
        
       %% Main loop
        while iter < maxiter
                iter = iter + 1;
                gamma_x = gamma_xk;  % Primal support
                z_x = z_xk;
                xk = xk_1;
                
              %% Update direction
               delta_x = iAtransAg_x * z_x(gamma_x);
               vdelta_x = zeros(n, 1);
               vdelta_x(gamma_x) = delta_x;
               
               pk = pk_old;
               dk_t = G(vdelta_x);
               dk = Gtrans(dk_t);
               
              %% Control the machine precision error at every optimization: line below
               % pk_temp = pk_old;
               % gammaL_temp = find(abs(abs(pk_old)-epsilon) < min(epsilon, 2*eps));
               % xk_temp = xk;
               % gammaX_temp = find(abs(xk) < eps);
               
               % Compute the step size
               [i_delta, x_shk, delta, chk_x] = update_primal(...
                   gamma_x, gamma_x, z_x, xk, vdelta_x, pk_old,...
                   dk, epsilon, lambda_shk);
               %
               % some check here
               %
               % old_delta = delta;
               if delta == inf
                   disp(delta * vdelta_x)
               end
               
               xk_1 = xk + delta * vdelta_x;
               pk_old = pk + delta * dk;
               epsilon_old = epsilon;
               epsilon = epsilon - delta;
               
              %% Check convergence criterion
               if epsilon <= tau
                       xk_1 = xk + (epsilon_old - tau) * vdelta_x;
                       break;
               end
               if chk_x == 1
                       % If an element is removed from gamma_x
                       % gamma_x_old = gamma_x;
                       len_gamma = length(gamma_x);
                       
                       x_idx = find(gamma_x == x_shk);
                       gamma_x(x_idx) = gamma_x(len_gamma);
                       gamma_x(len_gamma) = x_shk;
                       gamma_xk = gamma_x(1:len_gamma - 1);
               
                       rowi = x_idx; % ith row of A is swapped with last row (x_shk)
                       colj = x_idx; % jth column of A is swapped with last column (lambda_shk)
                       AtransAg_xij = swap_row(AtransAg_x, rowi, len_gamma);
                       AtransAg_xij = swap_col(AtransAg_xij, colj, len_gamma);
                       iAtransAg_xij = swap_row(iAtransAg_x, colj, len_gamma);
                       iAtransAg_xij = swap_col(iAtransAg_xij, rowi, len_gamma);
                       
                       AtransAg_x = AtransAg_xij(1:len_gamma-1,1:len_gamma-1);
                       iAtransAg_x = update_inverse(AtransAg_xij, iAtransAg_xij, 2);
                       xk_1(x_shk) = 0;
               else
                       % If an element is added to gamma_x
                       gamma_xk = [gamma_x; i_delta];
                       new_x = i_delta;
                       
                       AtransgxAnx = A(:, gamma_x)' * A(:, new_x);
                       AtransAg_x_mod = [AtransAg_x, AtransgxAnx;
                               AtransgxAnx', A(:, new_x)' * A(:, new_x)];
                       
                       AtransAg_x = AtransAg_x_mod;
                       iAtransAg_x = update_inverse(AtransAg_x, iAtransAg_x, 1);
                       xk_1(i_delta) = 0;
                       gamma_x = gamma_xk;
               end
               
               z_xk = zeros(n, 1);
               z_xk(gamma_xk) = -sign(pk_old(gamma_xk));
               pk_old(gamma_x) = sign(pk_old(gamma_x)) * epsilon;
        
        end
        
        x = xk_1;
        total_iter = iter;
        total_time = cputime - t0;
        disp('iter :');
        disp(iter);
        disp('total time :');
        disp(total_time);
        
end


function [i_delta, x_shk, delta, chk_x] = update_primal(gamma_x, gamma_lambda,...
        z_x, x_k, vdelta_x, pk, dk, epsilon, lambda_shk)
        
        n = length(x_k);
        
        % gamma_lambda^c
        temp_gamma = zeros(n, 1);
        temp_gamma(gamma_lambda) = gamma_lambda;
        gamma_lc = find([1:n]' ~= temp_gamma);
        
        % for delta^pos
        delta_pos1_constr = (epsilon-pk(gamma_lc))./(1+dk(gamma_lc));
        delta_pos1_idx = find(delta_pos1_constr > 0);
        delta_pos1 = delta_pos1_constr(delta_pos1_idx);
        [delta_1, i_delta1] = min(delta_pos1);
        if isempty(delta_1)
                delta_1 = inf;
        end
        delta_pos2_constr = (epsilon+pk(gamma_lc))./(1-dk(gamma_lc));
        delta_pos2_idx = find(delta_pos2_constr > 0);
        delta_pos2 = delta_pos2_constr(delta_pos2_idx);
        [delta_2, i_delta2] = min(delta_pos2);
        if isempty(delta_2)
                delta_2 = inf;
        end
        
        if delta_1 > delta_2
                delta = delta_2;
                i_delta = gamma_lc(delta_pos2_idx(i_delta2));
        else
                delta = delta_1;
                i_delta = gamma_lc(delta_pos1_idx(i_delta1));
        end
        
        % for delta^neg
        delta_neg_constr = (-x_k(gamma_x)./vdelta_x(gamma_x));
        delta_neg_idx = find(delta_neg_constr > 0);
        [delta3, i_delta3] = min(delta_neg_constr(delta_neg_idx));
        x_shk_idx = gamma_x(delta_neg_idx(i_delta3));
        
        % a new element enters the support of lambda
        chk_x = 0;
        x_shk = [];
        % delta^neg <= delta^pos
        if delta3 > 0 & delta3 <= delta
                % an element is removed from support of x
                chk_x = 1;
                delta = delta3;
                x_shk = x_shk_idx;
        end

end

function B = swap_row(A, r1, r2)
        
        B = A;
        temp_row = B(r1, :);
        B(r1, :) = B(r2, :);
        B(r2, :) = temp_row;

end

function B = swap_col(A, c1, c2)
        
        B = A;
        temp_col = B(:, c1);
        B(:, c1) = B(:, c2);
        B(:, c2) = temp_col;

end

function iAtB = update_inverse(AtB, iAtB_old, flag)
        % This function uses matrix inversion lemma to update
        % the inverse of square matrix after addition or removal
        % of a row-column pair.
        %
        % Written by: Salman Asif, Georgia Tech
        % Email: sasif@ece.gatech.edu
        n = size(AtB,1);

        A12 = AtB(1:n-1,n);
        A21 = AtB(n,1:n-1);
        A22 = AtB(n,n);

        if flag == 1  % add columns
                
                iA11 = iAtB_old;
                size(iA11)
                size(A12)
                iA11A12 = iA11*A12;
                A21iA11 = A21*iA11;
                S = A22-A21*iA11A12;
                Q11_right = iA11A12*(A21iA11/S);

                iAtB = zeros(n);
                % iAtB = [Q11 Q12; Q21 Q22];
                iAtB(1:n-1,1:n-1) = iA11+ Q11_right;
                iAtB(1:n-1,n) = -iA11A12/S;
                iAtB(n,1:n-1) =  -A21iA11/S;
                iAtB(n,n) = 1/S;

        elseif flag == 2  % delete columns
                
                Q11 = iAtB_old(1:n-1,1:n-1);
                Q12 = iAtB_old(1:n-1,n);
                Q21 = iAtB_old(n,1:n-1);
                Q22 = iAtB_old(n,n);
                Q12Q21_Q22 = Q12*(Q21/Q22);
                iAtB = Q11 - Q12Q21_Q22;
                
        end

end
