clc;
clear;
close all;

%% Experiment settings
rng(2026);
trainRatio = 0.10;
sparseNoiseDensity = 0.30;
sparseNoiseScale = 0.30;
dataFile = fullfile(fileparts(mfilename('fullpath')), 'cadata');
resultFile = fullfile(fileparts(mfilename('fullpath')), 'cadata_regression_sparse_noise_030_results.csv');

%% Load cadata in LIBSVM regression format
[y, X] = readLibsvmRegression(dataFile);
numSamples = size(X, 1);
perm = randperm(numSamples);
numTrain = floor(trainRatio * numSamples);
trainIdx = perm(1:numTrain);
testIdx = perm(numTrain+1:end);

Xtrain = X(trainIdx, :);
ytrain = y(trainIdx);
Xtest = X(testIdx, :);
ytest = y(testIdx);

% Add sparse noise to the training response only. The clean test response is
% kept unchanged so that the reported error measures generalization quality.
[ytrain, sparseNoise] = addSparseResponseNoise(ytrain, sparseNoiseDensity, sparseNoiseScale);

%% Standardize by training statistics and add intercept
muX = mean(Xtrain, 1);
sigmaX = std(Xtrain, 0, 1);
sigmaX(sigmaX == 0) = 1;

yMean = mean(ytrain);
yScale = std(ytrain);
if yScale == 0
    yScale = 1;
end

Atrain = [ones(numTrain, 1), (Xtrain - muX) ./ sigmaX];
btrain = (ytrain - yMean) ./ yScale;
Atest = [ones(numSamples - numTrain, 1), (Xtest - muX) ./ sigmaX];

% L1NormSolver constructs A1 from the first n rows, so place a full-rank
% row subset at the front without changing the training set itself.
[Atrain, btrain] = moveFullRankRowsToFront(Atrain, btrain);

methodNames = {
    'L1PTB';
    'L1linprog';
    'flag1-L1RES';
    'flag2-GPSRbasic';
    'flag3-TNIPM';
    'flag4-Homotopy';
    'flag5-SpaRSA';
    'flag6-YALL1';
    'flag7-POB';
    'LeastSquares'
};

numMethods = numel(methodNames);
trainTime = nan(numMethods, 1);
testRelativeError = nan(numMethods, 1);
status = repmat({'not_run'}, numMethods, 1);

fprintf('cadata regression: %d training samples, %d testing samples, %d features plus intercept.\n', ...
    size(Atrain, 1), size(Atest, 1), size(Atrain, 2) - 1);
fprintf('Sparse training response noise: density = %.2f, scale = %.2f, nonzeros = %d.\n', ...
    sparseNoiseDensity, sparseNoiseScale, nnz(sparseNoise));

for k = 9:numMethods
    name = methodNames{k};
    fprintf('Running %s ...\n', name);
    try
        timer = tic;
        switch k
            case 1
                evalc('x = L1perturbation(Atrain, btrain);');
            case 2
                x = L1linprog(Atrain, btrain);
            case {3, 4, 5, 6, 7, 8, 9}
                flag = k - 2;
                evalc('x = L1NormSolver(Atrain, btrain, flag);');
            case 10
                x = Atrain \ btrain;
        end
        trainTime(k) = toc(timer);

        ypred = yMean + yScale * (Atest * x);
        testRelativeError(k) = norm(ypred - ytest) / norm(ytest);
        status{k} = 'ok';
        fprintf('  time = %.6f s, test relative error = %.12g\n', ...
            trainTime(k), testRelativeError(k));
    catch ME
        trainTime(k) = toc(timer);
        status{k} = ME.message;
        fprintf('  failed after %.6f s: %s\n', trainTime(k), ME.message);
    end
end

writeResultsCsv(resultFile, methodNames, trainTime, testRelativeError, status);
fprintf('\nResults written to %s\n', resultFile);

fprintf('\n%-18s %14s %22s %s\n', 'Method', 'TrainTimeSec', 'TestRelativeError', 'Status');
for k = 1:numMethods
    fprintf('%-18s %14.6f %22.12g %s\n', methodNames{k}, trainTime(k), testRelativeError(k), status{k});
end

function [y, X] = readLibsvmRegression(filename)
    fid = fopen(filename, 'r');
    if fid < 0
        error('Cannot open data file: %s', filename);
    end
    cleaner = onCleanup(@() fclose(fid));

    lines = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
    lines = lines{1};
    numRows = numel(lines);
    y = zeros(numRows, 1);
    X = zeros(numRows, 0);

    for i = 1:numRows
        tokens = strsplit(strtrim(lines{i}));
        if isempty(tokens) || isempty(tokens{1})
            continue;
        end
        y(i) = str2double(tokens{1});
        for j = 2:numel(tokens)
            pair = strsplit(tokens{j}, ':');
            if numel(pair) ~= 2
                error('Invalid LIBSVM token at row %d: %s', i, tokens{j});
            end
            featureIndex = str2double(pair{1});
            featureValue = str2double(pair{2});
            if featureIndex > size(X, 2)
                X(:, end+1:featureIndex) = 0;
            end
            X(i, featureIndex) = featureValue;
        end
    end
end

function [Aout, bout] = moveFullRankRowsToFront(A, b)
    [m, n] = size(A);
    if m <= n
        error('Training matrix must have more rows than columns.');
    end

    [~, R, pivot] = qr(A', 'vector');
    tol = max(size(A)) * eps(norm(R, 'fro'));
    rankA = sum(abs(diag(R)) > tol);
    if rankA < n
        error('Training matrix is rank deficient: rank=%d, columns=%d.', rankA, n);
    end

    frontRows = pivot(1:n);
    mask = true(m, 1);
    mask(frontRows) = false;
    order = [frontRows(:); find(mask)];
    Aout = A(order, :);
    bout = b(order);
end

function [yNoisy, noise] = addSparseResponseNoise(y, density, scale)
    if density < 0 || density > 1
        error('Sparse noise density must be in [0, 1].');
    end
    if scale < 0
        error('Sparse noise scale must be nonnegative.');
    end

    numRows = numel(y);
    numNoisy = round(density * numRows);
    noise = zeros(numRows, 1);
    if numNoisy > 0 && scale > 0
        idx = randperm(numRows, numNoisy);
        sigma = std(y);
        if sigma == 0
            sigma = 1;
        end
        noise(idx) = scale * sigma * randn(numNoisy, 1);
    end
    yNoisy = y + noise;
end

function writeResultsCsv(filename, methodNames, trainTime, testRelativeError, status)
    fid = fopen(filename, 'w');
    if fid < 0
        error('Cannot write result file: %s', filename);
    end
    cleaner = onCleanup(@() fclose(fid));

    fprintf(fid, 'Method,TrainTimeSec,TestRelativeError,Status\n');
    for i = 1:numel(methodNames)
        fprintf(fid, '%s,%.12g,%.12g,%s\n', ...
            csvEscape(methodNames{i}), trainTime(i), testRelativeError(i), csvEscape(status{i}));
    end
end

function s = csvEscape(value)
    s = char(value);
    s = strrep(s, '"', '""');
    if any(s == ',') || any(s == '"') || any(s == newline) || any(s == char(13))
        s = ['"', s, '"'];
    end
end
