function x = L1OptLinProg(A, b)
    
    % size(A) = (m-n, m)
    [~, m] = size(A);
    % Basic-Pursuit, target function = sum(u, v)
    t = ones(2 * m, 1);
    % Aeq[u v] = Aeq_ * (u - v)
    Aeq = [A, -A];
    % u, v > 0
    lb = zeros(2 * m, 1);
    % r0 = [u v]
    x0 = linprog(t, [], [], Aeq, b, lb, []);
    % Minimal L1 module residual vector, r = u - v
    x = x0(1:m) - x0(m+1:2*m);
    
end