function x = BP_iterative(A, b, radius, max_iter)

    if nargin < 4
        max_iter = 3000;
    elseif nargin < 3
        radius = 0;
    end

    [m, n] = size(A);
    
    % Initilization
    v = zeros(m, 1);
    x = zeros(n, 1);
    v_ = v - (A * x - b);
    alpha = 0.02;
    beta = 0.999 / norm(A, 2)^2 * alpha;
    
    k = 0; T = 6;
    t = 0; tau = 4;
    % main loop
    while k < max_iter
        x_ = x;
        x = soft(x - beta / alpha * A' * (2 * v - v_), 1 / alpha);
        if norm(x - x_) / (norm(x) + eps) < 1e-8 %&& norm(x) > eps
            break;
        end
        p = A * x + v - b;
        v_ = v;
        norm_p = norm(p, 2);
        if norm_p <= radius
            v = 0;
        else
            v = (1 - radius / norm_p) * p;
        end
        k = k + 1;
        if t < T && (~mod(k, 20))
            alpha = tau * alpha;
            beta = tau * beta;
            t = t + 1;
        end
    end
    disp(k);

end

function y = soft(x, tau)
    y = sign(x) .* max(abs(x) - tau, 0);
end