function [ x, r ] = L1NormSolver(A, b, flag, omega, eps, min_iter)
    
    if nargin < 6
        min_iter = 0;
    end

    if nargin < 5
        eps = 1e-8;
    end

    if nargin < 4
        omega = [];
    end

    if nargin < 3
        flag = 1;
    end
    
    [m, n] = size(A);
    if m <= n
        error("A_rows must greater than A_columns");
    end
    % Trans A into two matrix(n x n and (m - n) x n)
    A1 = A(1:n, :);
    A2 = A(n+1:m, :);
    if rank(A1) >= n
        % inverse of A1 
        A1_ = inv(A1);
    else
        % Generalized inverse of A1 
        A1_ = pinv(A1);
    end
    % c_ij = A2 * inv(A1)
    c = A2 * A1_;
    % D = [-c I(m-n)]
    D = [-c, eye(m - n)];
    if ~isempty(omega)
        if isvector(omega)
            D = D ./ reshape(omega, 1, []);
        else
            D = D / omega;
        end
    end
    % r(n+1:m) = A2*inv(A1)*r(1:n) + w
    w = c * b(1:n) - b(n+1:m);
    % Solving compatible linear equations Ax = b + r
    switch flag
        case 1
            r = L1OptLinProg(D, w);  % L1-RES
        case 2
            r = L1OptGPSRbasic(D, w, eps);
        case 3
            r = l1_ls(D, w, eps);  % L1OptTNIPM
        case 4
            r = L1OptHomotopy(D, w, eps);
        case 5
            r = SpaRSA(w, D, eps);  % L1OptIST, some bug when numeric test
        case 6
            opts.tol = 1e-8;
            opts.rho = eps;
            r = yall1(D, w, opts);  % L1OptADM
        case 7
            r = L1OptPOB(D, w, eps, 1.5e+4, min_iter);
        case 8
            r = L1OptGPSRBB(D, w, eps);
    end
    % disp(sum(r<=1e-10));
    x = A \ (b + r);
    % x = pinv(A) * (b + r);

end
