function [ x, r ] = L1NormSolver(A, b, flag)
    
    if nargin < 3
        flag = 1;
    end
    
    [m, n] = size(A);
    if m <= n
        error("A_rows must greater than A_columns");
    end
    % Trans A into two matrix(n x n and (m - n) x n)
    A1 = A(1:n, :);
    A2 = A(n+1:m, :);
    if rank(A) >= n
        % inverse of A1 
        A1_ = inv(A1);
    else
        % Generalized inverse of A1 
        A1_ = pinv(A1);
    end
    % c_ij = A2 * inv(A1)
    c = A2 * A1_;
    % D = [-c I(m-n)]
    D = [-c, eye(m - n)];
    % r(n+1:m) = A2*inv(A1)*r(1:n) + w
    w = c * b(1:n) - b(n+1:m);
    % Solving compatible linear equations Ax = b + r
    switch flag
        case 1
            r = BP_linprog(D, w);
        case 2
            r = BP_iterative(D, w, 1e-8);
        case 3
            r = BP_homotopy(D, w, 1e-8);
        case 4
            r = BP_GPSRbasic(D, w, 1e-8);
        case 5
            r = BP_GPSRBB(D, w, 1e-8);
        case 6
            r = l1_ls(D, w, 1e-8);
        case 7
            r = SpaRSA(w, D, 1e-8); % some bug when numeric test
        case 8
            opts.tol = 1e-8;
            opts.rho = 1e-8;
            r = yall1(D, w, opts);
        case 9
            r = BP_primaldual(D, w);
        case 10
            r = NESTA(D, pinv(D), w, 1e-3, 1e-3); % not work
        case 11
            r = FPC_AS(m, D, w, 1e-8, []); % worse
    end
    % disp(sum(r<=1e-10));
    x = A \ (b + r);
    % x = pinv(A) * (b + r);

end
