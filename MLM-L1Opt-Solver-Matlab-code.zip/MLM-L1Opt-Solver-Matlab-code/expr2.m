
clc;
clear;
close all;

%% initialize
k = 30;
m = 256;
n = 128;
t = zeros(k, 9);
err = zeros(k, 9);

%% main
B = load(sprintf("data/randn%dx%dx%d.txt", m, n, k));

rho = 0.5;
N = load(sprintf("data/noise%dx1x30-%d.txt", m, rho*100));

AA = transpose(B(:, 1:end-1));
uu = B(:, end);

for i = 1:1
    A = AA(:, n*i-n+1:n*i);
    u = uu(n*i-n+1:n*i, 1);
    b = A * u;
    % add sprase noise
    b = b + N(m*i-m+1:m*i, 1);
    tmp = tic;
    alpha1 = L1perturbation(A, b);
    t(i, 1) = toc(tmp);
    tmp = tic;
    alpha2 = L1linprog(A, b);
    t(i, 2) = toc(tmp);
    err(i, 1) = norm(alpha1 - u) / norm(u);
    err(i, 2) = norm(alpha2 - u) / norm(u);
    for j = 1:7
        % 1 - for l1-residual
        tmp = tic;
        alpha3 = L1NormSolver(A, b, j);
        t(i, 2+j) = toc(tmp);
        err(i, 2+j) = norm(alpha3 - u) / norm(u);
    end
end

t = mean(t);
err = mean(err);
for i = 1:size(err, 2)
    fprintf("%.20f\t%.4f\t%.1f\n", err(i), t(i), t(i)*1000);
end

semilogy(1:9, t)
hold on
semilogy(1:9, err)
