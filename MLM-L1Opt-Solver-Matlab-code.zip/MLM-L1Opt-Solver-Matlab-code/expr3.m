clc;
clear;
close all;

%% initialize
k = 30;
n = 100;
rho = 0.25;

redundancyRatio = [1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.2, 2.3, 2.4, 2.5];
mList = round(n * redundancyRatio);

methodNames = { ...
    'L1perturbation', ...
    'L1linprog', ...
    'L1-RES', ...
    'GPSRbasic', ...
    'TNIPM', ...
    'Homotopy', ...
    'SpaRSA', ...
    'ADM', ...
    'POB', ...
    'GPSRBB'};

methodCount = numel(methodNames);
ratioCount = numel(redundancyRatio);

timeAll = nan(ratioCount, k, methodCount);
errAll = nan(ratioCount, k, methodCount);
timeMean = nan(ratioCount, methodCount);
errMean = nan(ratioCount, methodCount);

scriptDir = fileparts(mfilename('fullpath'));
dataDir = fullfile(scriptDir, 'data');
resultFile = fullfile(scriptDir, 'OLE_redundancy_results.csv');

%% main
for ratioIdx = 1:ratioCount
    m = mList(ratioIdx);

    dataFile = fullfile(dataDir, sprintf('randn%dx%dx%d.txt', m, n, k));
    noiseFile = fullfile(dataDir, sprintf('noise%dx1x%d-%d.txt', m, k, rho * 100));

    if ~isfile(dataFile)
        error('Missing data file: %s', dataFile);
    end
    if ~isfile(noiseFile)
        error('Missing noise file: %s', noiseFile);
    end

    B = load(dataFile);
    N = load(noiseFile);

    AA = transpose(B(:, 1:end-1));
    uu = B(:, end);

    for sampleIdx = 1:k
        A = AA(:, n*sampleIdx-n+1:n*sampleIdx);
        u = uu(n*sampleIdx-n+1:n*sampleIdx, 1);
        b = A * u;
        b = b + N(m*sampleIdx-m+1:m*sampleIdx, 1);

        for methodIdx = 1:methodCount
            tmp = tic;
            try
                alpha = solveByMethod(A, b, methodIdx);
                timeAll(ratioIdx, sampleIdx, methodIdx) = toc(tmp);
                errAll(ratioIdx, sampleIdx, methodIdx) = norm(alpha - u) / norm(u);
            catch ME
                timeAll(ratioIdx, sampleIdx, methodIdx) = toc(tmp);
                warning('%s failed at m=%d, sample=%d: %s', ...
                    methodNames{methodIdx}, m, sampleIdx, ME.message);
            end
        end
    end

    timeMean(ratioIdx, :) = reshape(mean(timeAll(ratioIdx, :, :), 2, 'omitnan'), 1, []);
    errMean(ratioIdx, :) = reshape(mean(errAll(ratioIdx, :, :), 2, 'omitnan'), 1, []);
end

%% record results
rowCount = ratioCount * methodCount;
RedundancyRatio = zeros(rowCount, 1);
Rows = zeros(rowCount, 1);
Columns = zeros(rowCount, 1);
Method = cell(rowCount, 1);
RelativeError = zeros(rowCount, 1);
TimeSecond = zeros(rowCount, 1);
TimeMillisecond = zeros(rowCount, 1);

rowIdx = 0;
for ratioIdx = 1:ratioCount
    for methodIdx = 1:methodCount
        rowIdx = rowIdx + 1;
        RedundancyRatio(rowIdx) = redundancyRatio(ratioIdx);
        Rows(rowIdx) = mList(ratioIdx);
        Columns(rowIdx) = n;
        Method{rowIdx} = methodNames{methodIdx};
        RelativeError(rowIdx) = errMean(ratioIdx, methodIdx);
        TimeSecond(rowIdx) = timeMean(ratioIdx, methodIdx);
        TimeMillisecond(rowIdx) = 1000 * timeMean(ratioIdx, methodIdx);
    end
end

resultTable = table(RedundancyRatio, Rows, Columns, Method, ...
    RelativeError, TimeSecond, TimeMillisecond);
writetable(resultTable, resultFile);

fprintf('\nAverage relative error and runtime under different data redundancy levels:\n');
disp(resultTable);
fprintf('Results saved to: %s\n', resultFile);

%% plot
figure;
semilogy(redundancyRatio, timeMean * 1000, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Data redundancy m/n');
ylabel('Average runtime (ms)');
legend(methodNames, 'Interpreter', 'none', 'Location', 'best');
title('Runtime under different data redundancy levels');

figure;
semilogy(redundancyRatio, errMean, '-s', 'LineWidth', 1.5);
grid on;
xlabel('Data redundancy m/n');
ylabel('Average relative error');
legend(methodNames, 'Interpreter', 'none', 'Location', 'best');
title('Relative error under different data redundancy levels');

function alpha = solveByMethod(A, b, methodIdx)
    switch methodIdx
        case 1
            alpha = L1perturbation(A, b);
        case 2
            alpha = L1linprog(A, b);
        otherwise
            alpha = L1NormSolver(A, b, methodIdx - 2);
    end
end
