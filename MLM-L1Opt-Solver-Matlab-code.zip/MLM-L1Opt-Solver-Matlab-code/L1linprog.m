function x = L1linprog(A, b)

    [m, n] = size(A);
    k = m + n;
    
    t = [ones(1, 2 * m), zeros(1, 2 * n)];
    
    I = eye(m);
    Aeq = [-I, I, A, -A];
    beq = b;
    lb = zeros(2 * k, 1);
    
    s = linprog(t, [], [], Aeq, beq, lb, []);
    
    x = s(2*m+1:m+k) - s(m+k+1:end);
    % r = s(1:m) - s(m+1:2*m);
    
end