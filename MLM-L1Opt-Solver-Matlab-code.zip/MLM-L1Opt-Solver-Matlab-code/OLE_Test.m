clear; clc;

m = 256;
n = 128;

%% random test
% 每个元素服从Gauss随机分布
A = 5 * randn(m, n);
% b = A * u, 则 Au - b = 0，u 即为我们要求的精确解
u = 3 * randn(n, 1);
b = A * u;
b = b + 10 * sprandn(m, 1, 0.3);

%% numeric test
A = [2 -1 -1; 
     1 -1 1;
     1 1 1;
     -1 2 -1;
     2 3 0];
b = [3 2 9 5 8]';
u = [2.3846, 1.0769, 0.6923]';

%% numeric test 2
A = [0.7394 -0.6567 -0.1485 1.0000;
    0.3476 -0.4756 -0.8081 1.0000;
    0.6315 -0.0370 0.7745 1.0000;
    0.9151 -0.0597 -0.3989 1.0000;
    0.6588 0.7434 0.1151 1.0000;
    0.5432 0.2720 -0.7943 1.0000;
    0.7827 0.4103 0.4680 1.0000;
    -0.4266 0.4941 -0.7576 1.0000;
    0.1569 0.7426 -0.6511 1.0000;
    0.3542 0.7516 0.5564 1.0000];
b = -1e-4 * [19 41 114 27 16 19 1 75 14 6]';

%% f(x) = exp(-x)
m = 201;
n = 7;
u = [0:0.02:4]';
A = zeros(m, n);
for i = 1:m
    for j = 1:n
        A(i, j) = (-1)^j / factorial(j);
    end
end
b = exp(-u);

%% numeric test 3
A = [5 3 4 12 4;
    9 7 3 19 13;
    6 6 0 12 12;
    9 9 7 25 11;
    3 0 1 4 2;
    8 1 8 17 1;
    1 9 8 18 2;
    3 1 1 5 3;
    0 9 3 12 6];
b = [7 4 2 7 7 7 3 5 3]';

%% main
alpha1 = L1NormSolver(A, b, 1);  % linprog
alpha2 = L1NormSolver(A, b, 3);  % 
% alpha2 = L1perturbation(A, b);

% 绘制原信号
p1 = plot(alpha1, 'b', 'LineWidth', 2);
hold on;
% 绘制恢复信号
p2 = plot(alpha2, 'r.-');
grid on;
hold off;
h = legend([p1, p2], 'Original', 'Recovery');
set(h, 'FontSize', 16, 'Location', 'NorthEast');
fprintf('\n相对误差：');  
% 恢复残差 
%disp(norm(alpha1 - u, 2) / norm(u));
%disp(norm(alpha2 - u, 2) / norm(u));
disp(norm(A * alpha1 - b, 1));
disp(norm(A * alpha2 - b, 1));
