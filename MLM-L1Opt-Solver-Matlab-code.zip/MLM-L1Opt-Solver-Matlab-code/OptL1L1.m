function [x, r] = OptL1L1(A, b, flag, lambda)

    if nargin < 4
        lambda = 1;
    end
    if nargin < 3
        flag = 1;
    end

    %% Initialize
    [m, n] = size(A);
    k = m + n;

    %% Trans to basis-pursuit problem
    % min ||z||_1, s.t. Dz=w, z>=0
    I = eye(m);
    D = [-I, I, A, -A];
    w = b;

    %% Solve
    % z = [r+; r-; x+; x-];
    switch flag
        case 1
            z = BP_linprog(D, w, lambda);
        case 2
            z = BP_homotopy(D, w, 1e-3);
        case 3
            z = BP_GPSRBB(D, w, 1e-3);
        case 4
            z = l1_ls(D, w, 1e-3);
        case 5
            z = SpaRSA(w, D, 1e-3);
        case 6
            opts.tol = 1e-8;
            opts.rho = 1e-3;
            z = yall1(D, w, opts);
        case 7
            z = FPC_AS(2*k, D, w, 1e-3, []);
    end
    % r = r+ - r-, x = x+ - x-
    r = z(1:m) - z(m+1:2*m);
    x = z(2*m+1:m+k) - z(m+k+1:2*k);

end


function z = BP_linprog(D, w, lambda)
    % k = 2 * (m + n)
    [m, k] = size(D);
    % Basic-Pursuit, target function = sum(u, v)
    t = [ones(2 * m, 1); lambda * ones(k - 2 * m, 1)];
    % z >= 0
    lb = zeros(k, 1);
    % z = [r+; r-; x+; x-]
    z = linprog(t, [], [], D, w, lb, []);
end