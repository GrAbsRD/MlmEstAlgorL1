clear; clc;

%% initialize
k = 30;
m = 256;
n = 128;
t = zeros(k, 1);
err = zeros(k, 1);

%% for diff m
% p = [1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 2.0, 2.5];
p = [1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.2, 2.3, 2.4, 2.5];
method = [1, 4, 6, 3, 7, 8, 2];
T = [];

for j = 1:10
n = 100;
m = int32(n * p(j));

% for j = 1:7  % this for diff method

%% main
B = load(['data/randn', num2str(m), 'x', num2str(n), 'x', num2str(k), '.txt']);
N = load(['data/noise', num2str(m), 'x1x30-25.txt']);
AA = transpose(B(:, 1:end-1));
uu = B(:, end);
for i = 1:k
    A = AA(:, n*i-n+1:n*i);
    u = uu(n*i-n+1:n*i, 1);
    b = A * u;
    % add sprase noise
    b = b + N(m*i-m+1:m*i, 1);
    tmp = tic;
    % alpha = L1linprog(A, b);
    % alpha = L1perturbation(A, b);
    % 1   - for l1-residual
    % 4,5 - for GPSR, 5 for GPSR_BB
    % 6   - for TNIPM
    % 3   - for Homotopy
    % 7   - for SpaRSA
    % 8   - for ADM
    % 2   - for POB
    alpha = L1NormSolver(A, b, 6);
    % alpha = L1NormSolver(A, b, method(j));
    t(i) = toc(tmp);
    err(i) = norm(alpha - u) / norm(u);
end

T = [T; mean(err), mean(t)];
end

%% plot
p = plot(1:k, t, 'r', 'LineWidth', 2);
grid on;
hold off;
h = legend([p], 'Linprog');
set(h, 'FontSize', 16, 'Location', 'NorthWest');
fprintf('\n恢复残差 ：');
disp(norm(A * alpha - b, 1));

disp([mean(err), mean(t)]);
