clc;
clear;
close all;

addpath pics\;

%% Experiment settings
scriptDir = fileparts(mfilename('fullpath'));
dataFile = fullfile(scriptDir, 'data/real_data_example_results.csv');
resultFile = fullfile(scriptDir, 'real_data_hurst_regression_results.csv');
figureFile = fullfile(scriptDir, '/pics/real_data_hurst_regression_fit.png');

%% Load log-scale R/S statistics
data = readtable(dataFile);
requiredColumns = {'log_scale', 'log_rs'};
if ~all(ismember(requiredColumns, data.Properties.VariableNames))
    error('Input CSV must contain columns: log_scale, log_rs.');
end

xdata = data.log_scale(:);
ydata = data.log_rs(:);
validRows = isfinite(xdata) & isfinite(ydata);
xdata = xdata(validRows);
ydata = ydata(validRows);

idx = floor(linspace(1, length(xdata), 100));
xdata = xdata(idx);
ydata = ydata(idx);

if numel(xdata) <= 2
    error('At least three valid data points are required for regression.');
end

A = [xdata, ones(numel(xdata), 1)];
b = ydata;

%% Estimate the slope H in log(R/S) = H log(scale) + intercept
methodNames = {
    'L1-LP';
    'L1-PTB';
    'L1-RES';
    'L1-GPSR';
    'L1-TNIPM';
    'L1-HP';
    'L1-IST';
    'L1-ADM';
    'L1-POB';
    'LS'
};

numMethods = numel(methodNames);
hurstIndex = nan(numMethods, 1);
intercept = nan(numMethods, 1);
l1Residual = nan(numMethods, 1);
l2Residual = nan(numMethods, 1);
trainTime = nan(numMethods, 1);
status = repmat({'not_run'}, numMethods, 1);
solutions = nan(2, numMethods);

fprintf('Real cognitive-information-processing data: %d valid log-scale R/S points.\n', numel(b));
fprintf('%-18s %14s %14s %14s %14s %s\n', ...
    'Method', 'HurstIndex', 'Intercept', 'L1Residual', 'TimeSec', 'Status');

for k = 1:numMethods
    name = methodNames{k};
    timer = tic;
    try
        switch k
            case 2
                evalc('coef = L1perturbation(A, b);');
            case 1
                coef = L1linprog(A, b);
            case {3, 5, 6}
                flag = k - 2;
                evalc('coef = L1NormSolver(A, b, flag, [], 1e-8);');
            case {4}
                flag = k - 2;
                evalc('coef = L1NormSolver(A, b, flag, [], 5e-2);');
            case {7}
                flag = k - 2;
                evalc('coef = L1NormSolver(A, b, flag, [], 1.9e-3);');
            case {8}
                flag = k - 2;
                evalc('coef = L1NormSolver(A, b, flag, [], 8e-9);');
            case {9}
                flag = k - 2;
                evalc('coef = L1NormSolver(A, b, flag, [], 8e-4, 100);');
            case 10
                coef = A \ b;
        end

        trainTime(k) = toc(timer);
        solutions(:, k) = coef(:);
        residual = A * coef - b;
        hurstIndex(k) = coef(1);
        intercept(k) = coef(2);
        l1Residual(k) = norm(residual, 1);
        l2Residual(k) = norm(residual, 2);
        status{k} = 'ok';
    catch ME
        trainTime(k) = toc(timer);
        status{k} = ME.message;
    end

    fprintf('%-18s %14.8f %14.8f %14.8g %14.6f %s\n', ...
        name, hurstIndex(k), intercept(k), l1Residual(k), trainTime(k), status{k});
end

writeResultsCsv(resultFile, methodNames, hurstIndex, intercept, ...
    l1Residual, l2Residual, trainTime, status);
fprintf('\nResults written to %s\n', resultFile);

%% Plot measured points and fitted regression lines
[xplot, order] = sort(xdata);
yplot = ydata(order);

xplot = xplot * log(10);
yplot = yplot * log(10);

% fig = figure('Color', 'w', 'Position', [100, 100, 980, 620]);
fig = fig_open(1080, 920);
plot(xplot, yplot, 'ko', 'LineWidth', 1.5, 'MarkerSize', 6, ...
    'DisplayName', 'Observed points');
hold on;
grid on;
ax = gca;
ax.YGrid = 'off';
ax.XGrid = 'off';
box on;

colors = lines(numMethods);
lineStyles = {'-', '--', ':', '-.', '-', '--', ':', '-.', '-', '--', '-'};
for k = 1:numMethods
    if strcmp(status{k}, 'ok')
        yfit = solutions(1, k) * xplot + solutions(2, k) * log(10);
        plot(xplot, yfit, 'LineWidth', 1.6, 'LineStyle', lineStyles{k}, ...
            'Color', colors(k, :), ...
            'DisplayName', sprintf('%s: H=%.4f', methodNames{k}, hurstIndex(k)));
    end
end

xlim([min(xplot)-0.1, max(xplot)+0.1])
ylim([min(yplot)-0.1, max(yplot)+0.1])
xlabel('$\ln(\mathcal{S})$', 'Interpreter','latex');
ylabel('$\ln(\mathcal{R})$', 'Interpreter','latex');
% title('Regression fit for Hurst index estimation on cognitive processing data');
legend('Location', 'southeast', 'Interpreter', 'none');
exportgraphics(fig, figureFile, 'Resolution', 300);
fprintf('Figure written to %s\n', figureFile);

function writeResultsCsv(filename, methodNames, hurstIndex, intercept, ...
    l1Residual, l2Residual, trainTime, status)

    fid = fopen(filename, 'w');
    if fid < 0
        error('Cannot write result file: %s', filename);
    end
    cleaner = onCleanup(@() fclose(fid));

    fprintf(fid, 'Method,HurstIndex,Intercept,L1Residual,L2Residual,TimeSec,Status\n');
    for i = 1:numel(methodNames)
        fprintf(fid, '%s,%.12g,%.12g,%.12g,%.12g,%.12g,%s\n', ...
            csvEscape(methodNames{i}), hurstIndex(i), intercept(i), ...
            l1Residual(i), l2Residual(i), trainTime(i), csvEscape(status{i}));
    end
end

function s = csvEscape(value)
    s = char(value);
    s = strrep(s, '"', '""');
    if any(s == ',') || any(s == '"') || any(s == newline) || any(s == char(13))
        s = ['"', s, '"'];
    end
end
