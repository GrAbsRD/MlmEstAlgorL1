function [x, info] = L1OptPOB2(A, b, radius, max_iter, tolGap, tolRel, tolFeas)

    if nargin < 3 || isempty(radius)
        radius = 0;
    end
    if nargin < 4 || isempty(max_iter)
        max_iter = 15000;
    end
    if nargin < 5 || isempty(tolGap)
        tolGap = 1e-8;
    end
    if nargin < 6 || isempty(tolRel)
        tolRel = 1e-9;
    end
    if nargin < 7 || isempty(tolFeas)
        tolFeas = 1e-10 * max(1, norm(b, 2));
    end

    [m, n] = size(A);

    % Initialization
    v = zeros(m, 1);
    x = zeros(n, 1);

    % For BP/BPDN, w0 = b, so v_{-1} = v0 - (A*x0 - b)
    v_prev = v - (A * x - b);

    Anorm = norm(A, 2);

    % Paper-style initialization for Algorithm 3
    alpha = (m / n) * 20 * Anorm^2 / (norm(A' * b, inf) + eps);
    beta  = 0.999 / Anorm^2 * alpha;

    k = 0;
    T = 6;
    t = 0;
    tau = 4;
    p_update = 20;

    relchg = inf;

    while k < max_iter
    
        x_old = x;
    
        % Algorithm 2, Step 1
        x = soft(x - (beta / alpha) * A' * (2 * v - v_prev), 1 / alpha);
    
        % Algorithm 2, Step 2
        p = A * x + v - b;
        v_prev = v;
    
        norm_p = norm(p, 2);
        if norm_p <= radius + eps
            v = zeros(m, 1);
        else
            v = (1 - radius / norm_p) * p;
        end
    
        k = k + 1;
    
        % Algorithm 3 parameter update
        if t < T && mod(k, p_update) == 0
            alpha = tau * alpha;
            beta  = tau * beta;
            t = t + 1;
        end
    
        % ---------- stopping criteria ----------
        resid = A * x - b;
        res_norm = norm(resid, 2);
    
        P = norm(x, 1);
    
        y = v;
        dual_scale = max(1, norm(A' * y, inf));
        y = y / dual_scale;
    
        D = -b' * y - radius * norm(y, 2);
    
        gap = P - D;
        relgap = gap / max(1, abs(P));
    
        relchg = norm(x - x_old, 2) / max(1, norm(x_old, 2));
        feasible = res_norm <= radius + tolFeas;
    
        if feasible && relgap < tolGap && relchg < tolRel
            break;
        end
    end

    info.iter = k;
    info.relchg = relchg;
    info.alpha = alpha;
    info.beta = beta;
    info.residual = norm(A * x - b, 2);
    info.l1norm = norm(x, 1);

end

function y = soft(x, tau)
    y = sign(x) .* max(abs(x) - tau, 0);
end