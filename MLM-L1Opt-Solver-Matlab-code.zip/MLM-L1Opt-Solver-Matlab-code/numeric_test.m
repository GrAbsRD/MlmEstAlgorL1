
clc;
clear;
close all;

A = [2 -1 -1; 
     1 -1  1;
     1  1  1;
    -1  2 -1;
     2  3  0];

b = [3; 2; 9; 5; 8];

u = [2.3846, 1.0769, 0.6923]';

% Ordinary L1-norm minimization
omega0 = ones(5,1);
alpha_l1 = L1NormSolver(A, b, 1, omega0);
r_l1 = A * alpha_l1 - b;
obj_l1 = sum(abs(r_l1));

% Weighted L1-norm minimization
omega = [1; 1; 10; 1; 1];
alpha_w = L1NormSolver(A, b, 1, omega);
r_w = A * alpha_w - b;
obj_w = sum(omega .* abs(r_w));

% Evaluate the ordinary L1 solution under the weighted objective
obj_l1_weighted = sum(omega .* abs(r_l1));

disp('Ordinary L1 solution:');
disp(alpha_l1);

disp('Residual of ordinary L1 solution:');
disp(r_l1);

disp('Ordinary L1 objective:');
disp(obj_l1);

disp('Weighted L1 solution:');
disp(alpha_w);

disp('Residual of weighted L1 solution:');
disp(r_w);

disp('Weighted L1 objective:');
disp(obj_w);

disp('Weighted objective of ordinary L1 solution:');
disp(obj_l1_weighted);
