function [x, iter] = L1perturbation(A, b)

    iter = 0;
    maxiter = 15;
    alpha = 0.01;
    [~, n] = size(A);
    
    x = zeros(n, 1);
    % x(1) = b(1) / A(1, 1);
    
    while iter < maxiter
 
        r = A * x - b;
        % zero index
        zeroidx = abs(r) < 1e-12;
        % disp(sum(zeroidx));
    
        while sum(zeroidx) < n
            x_ = x;
            A1 = A(zeroidx, :);
            A2 = A(~zeroidx, :);
            % b2 = b(~nonidx);
            r2 = r(~zeroidx);
            % nonzero perturbation vector
            nsp = null(A1);
            p = nsp(:, end);
            % set step size
            n2 = length(r2);
            f = zeros(n2, 1);
            epsm = zeros(n2, 1);
            for i = 1:n2
                em = zeros(n2, 1);
                em(i) = 1;
                eA2p = em' * (A2 * p);
                if eA2p == 0
                    f(i) = inf;
                    continue;
                end
                epsm(i) = (em' * -r2) / eA2p;
                f(i) = norm(r2 + epsm(i) * A2 * p, 1);
            end
            [~, epsidx] = min(f);
            % set new trial solution
            x = x_ + epsm(epsidx) * p;
            % check
            % disp(norm(b - A * x, 1) < norm(b - A * x_, 1))
            r = A * x - b;
            % zero index
            zeroidx = abs(r) < 1e-12;
            % disp(sum(zeroidx));
        end
        % fprintf("Now residual error vector has at least %d zero elements\n", n);
    
        A1 = A(zeroidx, :);
        A2 = A(~zeroidx, :);
        r2 = r(~zeroidx);
        c = pinv(A1') * A2' * sign(r2);
    
        iter = iter + 1;
    
        if norm(c, inf) <= 1
            break;
        else
            en = zeros(length(c), 1);
            en(abs(c) > 1) = 1;
            x = x + alpha * pinv(A1) * en;
        end
    
    end
    
    disp(iter);
    
end