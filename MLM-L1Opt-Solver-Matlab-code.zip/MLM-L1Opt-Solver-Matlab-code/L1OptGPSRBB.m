%
% Based on GPSR_BB version 5.0, December 4, 2007
%
% This function solves the convex problem 
% arg min_x = 0.5*|| y - A x ||_2^2 + tau || x ||_1
% using the algorithm GPSR-BB, described in the following paper
%
% "Gradient Projection for Sparse Reconstruction: Application
% to Compressed Sensing and Other Inverse Problems"
% by Mario A. T. Figueiredo, Robert D. Nowak, Stephen J. Wright,
% Journal of Selected Topics on Signal Processing, December 2007
% (to appear).
% 
% -----------------------------------------------------------------------
% Copyright (2007): Mario Figueiredo, Robert Nowak, Stephen Wright
% 
% GPSR is distributed under the terms
% of the GNU General Public License 2.0.
% 
% Permission to use, copy, modify, and distribute this software for
% any purpose without fee is hereby granted, provided that this entire
% notice is included in all copies of any software which is or includes
% a copy or modification of this software and in all copies of the
% supporting documentation for such software.
% This software is being provided "as is", without any express or
% implied warranty.  In particular, the authors do not make any
% representation or warranty of any kind concerning the merchantability
% of this software or its fitness for any particular purpose."
% ----------------------------------------------------------------------
% 
% Please check for the latest version of the code and paper at
% www.lx.it.pt/~mtf/GPSR
%
%  ===== Required inputs =============
%     
%  A: if y and x are both 1D vectors, A can be a 
%     k*n (where k is the size of y and n the size of x)
%     matrix or a handle to a function that computes
%     products of the form A*v, for some vector v.
%     In any other case (if y and/or x are 2D arrays), 
%     A has to be passed as a handle to a function which computes 
%     products of the form A*x; another handle to a function 
%     AT which computes products of the form A'*x is also required 
%     in this case. The size of x is determined as the size
%     of the result of applying AT.
%
%  b: 1D vector or 2D array (image) of observations
%
%  tau: usually, a non-negative real parameter of the objective 
%       function (see above). It can also be an array, the same 
%       size as x, with non-negative entries; in this  case,
%       the objective function weights differently each element 
%       of x, that is, it becomes
%       0.5*|| y - A x ||_2^2 + tau^T * abs(x)
%
% ============ Outputs ==============================
%   x = solution of the main algorithm
%
%   total_iter = Iteration counts.
%
%   total_time = CPU time after each iteration.
% ========================================================
%

function [x, total_iter, total_time] = L1OptGPSRBB(A, b, tau, maxiter)
    
    %% Initialization
    if nargin < 4
        maxiter = 10000;
    elseif nargin < 3
        tau = 1e-5;
    end
       
    % sufficient decrease parameter for GP line search
    alpha = 1.0;
    alphamin = 1e-30;
    alphamax = 1e30;

    % Precompute A'*y since it'll be used a lot
    Atb = A' * b;
    x = A' * zeros(size(b));
    
    % initialize u and v
    u = x .* (x >= 0);
    v = -x .* (x < 0);
    
    % start the clock
    t0 = cputime;
    
    % initilize criterion parameters
    iter = 1;
    tolA = 1e-5;
    
    % Compute and store initial value of the objective function
    resid =  b - A * x;  % b - A * (u - v)
    
    % Compute the useful quantity resid_base
    resid_base = b - resid;  % A * (u - v)
    
    %% Main loop
    while iter <= maxiter

        % compute gradient
        term = A' * resid_base - Atb;  % 0.5*||y-A(u-v)||_2^2 / d*
        gradu = term + tau;
        gradv = -term + tau;

        % projection and computation of search direction vector
        du = max(u - alpha*gradu, 0.0) - u;
        dv = max(v - alpha*gradv, 0.0) - v;
        dx = du - dv;
        u_guess = u;
        v_guess = v;
        
        % calculate useful matrix-vector product involving dx
        auv = A * dx;
        dGd = auv' * auv;
        
        % calculate minimizer along the direction (du, dv)
        lambda0 = -(gradu'*du + gradv'*dv)/(realmin+dGd);
        lambda = min(lambda0, 1);
        
        % update parameters
        u_improve = u_guess + lambda * du;
        v_improve = v_guess + lambda * dv;
        uvmin = min(u_improve, v_improve);
        u = u_improve - uvmin;
        v = v_improve - uvmin;
        x = u - v;
        
        % update residual
        resid = b - resid_base - lambda * auv;
        
        % compute new alpha
        dd  = du(:)'*du(:) + dv(:)'*dv(:);  
        if dGd <= 0
            alpha = alphamax;
        else
            alpha = min(alphamax,max(alphamin,dd/dGd));
        end
        resid_base = resid_base + lambda * auv;
        
        % update iteration counts, store results and times
        iter = iter + 1;
        % stopping criterion based on relative norm of step taken
        delta_x_criterion = norm(dx) / norm(x);
        if delta_x_criterion <= tolA
            break;
        end
        
    end  % end of the main loop of the GP algorithm
       
    %% Print results
    nz_x = (x~=0.0); num_nz_x = sum(nz_x(:));
    fprintf(1,'Number of non-zero components = %d\n',num_nz_x);
       
    total_iter = iter;
    total_time = cputime - t0;
        
end
    
