
clc; clear;

%% noise free case
data = readtable("time-error.xlsx", "Sheet", "Noise-Free");

alg = unique(data.Var1); % 提取唯一算法名称

% 创建图形并设置为两行一列布局
fig = fig_open(800, 800);
tiledlayout(2, 1, 'Parent', fig)

nexttile
bar(data.relativeError * 100, 0.45, 'FaceColor', '#D15354', ...
    'EdgeColor', 'black', 'LineWidth', 2.5);
% plot(data.relativeError * 100, '-o', 'LineWidth', 2.5, 'MarkerSize', 9, ...
%     'MarkerEdgeColor', '#D15354', ...
%     'MarkerFaceColor', '#D15354', ...
%     'Color', '#D15354');
set(gca, 'YScale', 'log');
xlim([0.5, 9.5]);
ylim([1e-14, 1e-10]);
set(gca, 'YTick', [1e-14, 1e-13, 1e-12, 1e-11, 1e-10])
set(gca, 'XTick', 1:length(alg), 'XTickLabel', data.Var1); % X轴刻度标签为空
ylabel('Relative Error (%)', 'Color', '#D15354');
grid on;

set(gca, 'GridLineStyle', ':');
box off;
ax = gca;
ax.YMinorGrid = 'off';
ax.YMinorTick = 'on';
set(ax,'fontsize',23,'LineWidth',2.5,'TickLength',[0.015, 0.01])
set(gca, 'XGrid', 'off');   % 关闭竖向网格线
xtickangle(90)
hold on

nexttile
bar(data.runningTime_ms_, 0.45, 'FaceColor', '#5291FF', ...
    'EdgeColor', 'black', 'LineWidth', 2.5);
set(gca, 'YScale', 'log');
xlim([0.5, 9.5]);
ylim([1, 1000]);
set(gca, 'YTick', [1, 10, 100, 1000])
set(gca, 'XTick', 1:length(alg), 'XTickLabel', data.Var1'); % X轴刻度标签为空
ylabel('Running Time (ms)', 'Color', '#5291FF');
grid on;
set(gca, 'GridLineStyle', ':');
box off;
ax = gca;
ax.YMinorGrid = 'off';
ax.YMinorTick = 'on';
set(ax,'fontsize',23,'LineWidth',2.5,'TickLength',[0.015, 0.01])
set(gca, 'XGrid', 'off');   % 关闭竖向网格线
xtickangle(90);
hold on

% print('./randn256x128-noise-free-ms.png', '-dpng', '-r300'); % 导出为 PNG 格式

%% different noise sparse ratio

fig = fig_open(800, 950);
tiledlayout(2, 1, 'Parent', fig)

nexttile
h = {};
barwidth = 0.22;
markers = {'-o', '-^', '-d'};
for ii = 1:3
    sheetname = sprintf("Noise-%d", ii * 25);
    data = readtable("time-error.xlsx", "Sheet", sheetname);
    sz = 9; % size of marker
    color_map = lines; % colormap used for lines and markers
    ylabel('Relative Error (%)');
    % x = (1:length(data.Var1)) - 0.12 - barwidth/2;
    % x+0.12*ii
    x = 1:length(data.Var1);
    h{end+1} = bar(x+barwidth*(ii-2), data.relativeError * 100, ...
        barwidth, 'FaceColor', color_map(ii,:), 'FaceAlpha', .8,...
        'EdgeColor', 'black', 'LineWidth', 2.5);
%     h{end+1}=plot(data.relativeError * 100, ...
%         markers{ii},'linewidth',2.5,'color',color_map(ii,:),...
%         'MarkerFaceColor',(1-color_map(ii,:))/1.5+color_map(ii,:), ...
%         'MarkerEdgeColor','black',...
%         'MarkerSize',sz);
    hold on
end
box off
xlim([0.5, 9.5])
ylim([0, 4.5])
yticks([0, 1,2,3,4,4.5])
yticklabels({'0', '1', '2', '3', '4', '4.5'});
grid on
set(gca, 'XGrid', 'off', 'GridLineStyle', ':');   % 关闭竖向网格线
set(gca, 'XTick', 1:length(alg), 'XTickLabel', data.Var1);
set(gca,'fontsize',23,'LineWidth',2.5,'TickLength',[0.015, 0.01])
xtickangle(90)
legend([h{1}, h{2}, h{3}], ["0.25", "0.50", "0.75"], ...
    'NumColumns', 3, 'Location', 'northeast')
hold on

nexttile
h = {};
for ii = 1:3
    sheetname = sprintf("Noise-%d", ii * 25);
    data = readtable("time-error.xlsx", "Sheet", sheetname);
    sz = 11; % size of marker
    color_map = lines; % colormap used for lines and markers
    ylabel('Running Time (ms)');
    x = 1:length(data.Var1);
    h{end+1}=bar(x+barwidth*(ii-2), data.runningTime_ms_, ...
        barwidth, 'FaceColor', color_map(ii,:), 'FaceAlpha', .8,...
        'EdgeColor', 'black', 'LineWidth', 2.5);
    hold on
end
box off
grid on
xlim([0.5, 9.5])
set(gca, 'YScale', 'log');
set(gca, 'XGrid', 'off', 'GridLineStyle', ':', 'YMinorGrid', 'off');   % 关闭竖向网格线
set(gca, 'XTick', 1:length(alg), 'XTickLabel', data.Var1);
set(gca,'fontsize',23,'LineWidth',2.5,'TickLength',[0.015, 0.01])
xtickangle(90)
set(gca, 'YTick', [1, 10, 100, 1000, 10000])
legend([h{1}, h{2}, h{3}], ["0.25", "0.50", "0.75"], ...
    'NumColumns', 3, ...
    'Location', 'northeast')

%% different DRL
n = 100;
sheetname = sprintf("error%d", n);
% sheetname = sprintf("time%d", n);
data = readtable("time-error.xlsx", "Sheet", sheetname, ...
    'VariableNamingRule', 'preserve');

fig = fig_open(800, 700);
h = {};
sz = 12; % size of marker
color_map = lines; % colormap used for lines and markers
markers = {'o-', 's-', 'd-', '^-', 'o--', 's--', 'd--', '^--'};
index = [1, 2, 4, 5];
for ii = 1:size(data, 2)-1
    % if ~ismember(ii, index)
    %     continue
    % end
    h{end+1} = plot(data{:, 1}, data{:, ii+1} * 100, ...
        markers{ii},'linewidth',2.5,'color',color_map(ii,:),...
        'MarkerFaceColor',color_map(ii, :), ...
        'MarkerEdgeColor','white',...
        'MarkerSize',sz);
    hold on
end
box on
grid on
set(gca, 'YScale', 'log', 'YMinorGrid', 'off');
set(gca, 'XGrid', 'off', 'GridLineStyle', ':');   % 关闭竖向网格线
% set(gca, 'XTick', 1:length(alg), 'XTickLabel', data.Var1);
set(gca,'fontsize',18,'LineWidth',1.5,'TickLength',[0.015, 0.01])
% 设置 x 轴刻度和标签
xlim([1.05, 2.55])
xticks([1.1, 1.3, 1.5, 1.7, 1.9, 2.1, 2.2, 2.3, 2.4, 2.5]);
xticklabels({'1.1', '1.3', '1.5', '1.7', '1.9', '2.1', '2.2', '2.3', '2.4', '2.5'});
% 设置 y 轴刻度和标签（递增顺序）
ylim([1e-12, 20])
yticks([1e-11, 1e-9, 1e-7, 1e-5, 1e-3, 1e-1, 10]);
yticklabels({'10^{-11}', '10^{-9}', '10^{-7}', '10^{-5}', '10^{-3}', '10^{-1}', '10'});
% 确保 MATLAB 渲染 LaTeX 数学公式
% set(gca, 'TickLabelInterpreter', 'latex');
hold on
