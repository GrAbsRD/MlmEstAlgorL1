#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  
#  Authors: Zhi-Qiang Feng and Hong-Yan Zhang, Hainan Normal University
#    email: z.q.feng@foxmail.com,  hongyan@hainnu.edu.cn    

import numpy as np
from numpy.linalg import norm, pinv
from scipy.linalg import null_space
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg
from scipy.optimize import linprog


class L1NormApproxSolver:

    def __init__(self, A: np.ndarray, b: np.ndarray):
        self.A = np.array(A)
        self.b = np.array(b).reshape(-1, 1)
        self.real_min = np.finfo(float).eps

    @staticmethod
    def search_min(vec: np.ndarray) -> list:
        if vec.size == 0:
            return [np.nan, None]
        v_min = np.min(vec)
        i_min = np.argmin(vec)
        return [v_min, i_min]

    @staticmethod
    def search_max(vec: np.ndarray) -> list:
        if vec.size == 0:
            return [np.nan, None]
        v_max = np.max(vec)
        i_max = np.argmax(vec)
        return [v_max, i_max]

    @staticmethod
    def swap_rows(A: np.ndarray, i: int, j: int) -> np.ndarray:
        """
        交换矩阵 A 的第 i 行和第 j 行
        :param A: 输入矩阵
        :param i: 行索引 i (从0开始)
        :param j: 行索引 j (从0开始)
        :return: 交换后的矩阵
        """
        A[i, :], A[j, :] = A[j, :], A[i, :]
        return A

    @staticmethod
    def swap_cols(A: np.ndarray, i: int, j: int) -> np.ndarray:
        """
        交换矩阵 A 的第 i 列和第 j 列
        :param A: 输入矩阵
        :param i: 列索引 i (从0开始)
        :param j: 列索引 j (从0开始)
        :return: 交换后的矩阵
        """
        A[:, i], A[:, j] = A[:, j], A[:, i]
        return A

    @staticmethod
    def sparse_rand(row: int, col: int, p: float) -> np.ndarray:
        """
        Imports
        -------
        import numpy as np
        from scipy.sparse import coo_matrix

        Parameters
        ----------
        row : int
            Rows of generate sparse-matrix.
        col : int
            Columns of generate sparse-matrix.
        p : float
            Proportion of non-zero elements in sparse-matrix.

        Returns
        -------
        scipy.sparse.coo.coo_matrix
            Returns a random generated sparse-matrix(m x n) M,
            try print(M) to see it or use M.toarray() for trans
            M to an array. (Gaussian distribution)

        Version: 1.0 writen by z.q.feng @2022.03.13
        """
        if type(row) is not int or type(col) is not int:
            raise TypeError('Rows(row) and Columns(col) must be an integer!')
        if p <= 0 or p > 1:
            raise ValueError('p must in (0, 1] !')
        # Counts of non-zero elements in sparse-matrix
        count = int(row * col * p)
        # Indexes of non-zero elements in sparse-matrix
        rows = np.random.randint(0, row, count)
        cols = np.random.randint(0, col, count)
        # Values of non-zero elements in sparse-matrix
        # (Gaussian distribution)
        data = np.random.randn(len(rows))
        M = coo_matrix((data, (rows, cols)), shape=(row, col))
        return M.toarray()

    def L1ApproxPerturbationCBS(self, alpha: float = 0.01, max_iter: int = 50) -> np.ndarray:
        [_, col] = np.shape(self.A)
        x = np.zeros([col, 1])
        iter = 0
        while iter < max_iter:
            r = self.A.dot(x) - self.b
            zero_idx = abs(r.ravel()) < 1e-12
            while np.sum(zero_idx) < col:
                A1 = self.A[zero_idx]
                A2 = self.A[~zero_idx]
                r_ = r[~zero_idx]
                if A1.size == 0:
                    kernel = np.eye(col)
                else:
                    kernel = null_space(A1)
                d = kernel[:, -1].reshape(-1, 1)
                v, f = np.zeros(r_.shape), np.zeros(r_.shape)
                for i in range(np.sum(~zero_idx)):
                    e = np.zeros(r_.shape)
                    e[i] = 1
                    eA2d = e.T.dot(A2.dot(d))
                    if eA2d == 0:
                        f[i] = np.inf
                    else:
                        v[i] = -e.T.dot(r_) / eA2d
                        f[i] = norm(r_ + v[i] * A2.dot(d), 1)
                i_min = np.argmin(f)
                x = x + v[i_min] * d
                r = self.A.dot(x) - self.b
                zero_idx = abs(r.ravel()) < 1e-12
            A1 = self.A[zero_idx]
            A2 = self.A[~zero_idx]
            r_ = r[~zero_idx]
            s = np.dot(pinv(A1.T), A2.T).dot(np.sign(r_))
            iter += 1
            if norm(s, np.inf) <= 1:
                break
            else:
                e = np.zeros(s.shape)
                e[abs(s) > 1] = 1
                x = x + alpha * pinv(A1).dot(e)
        print("Iteration for {:d} times.".format(iter))
        return x

    def L1ApproxLinProg(self) -> np.ndarray:
        [row, col] = np.shape(self.A)
        d = 2 * (row + col)
        t = np.vstack([np.ones([2 * row, 1]), np.zeros([2 * col, 1])])
        Aeq = np.hstack([-np.eye(row), np.eye(row), A, -A])
        bounds = [(0, None) for _ in range(d)]
        y = linprog(t, A_eq=Aeq, b_eq=self.b, bounds=bounds, method='highs')['x']
        x = y[2 * row:2 * row + col] - y[2 * row + col:d]
        return x.reshape(-1, 1)

    def L1ApproxViaMinREV(self, l1opt_fun: str = "linprog", **kwargs) -> np.ndarray:
        [row, col] = np.shape(self.A)
        A1 = A[:col, :]
        A2 = A[col:, :]
        A1inv = pinv(A1)
        D = np.hstack([-A2.dot(A1inv), np.eye(row - col)])
        w = A2.dot(A1inv).dot(b[:col]) - b[col:]
        # 确保l1opt_fun选择正确的函数
        opt_fun_map = {
            "LINPROG": self.L1OptLinProg,
            "GPSR": self.L1OptGPSR,
            "TNIPM": self.L1OptTNIPM,
            "HOMOTOPY": self.L1OptHomotopy,
            "IST": self.L1OptIST,
            "ADM": self.L1OptADM,
            "POB": self.L1OptPOB,
        }
        # 根据l1opt_fun的值选择合适的优化函数
        if l1opt_fun.upper() not in opt_fun_map:
            raise ValueError(f"Unknown optimization function: {l1opt_fun}")
        fun = opt_fun_map[l1opt_fun.upper()]  # 选择优化函数
        r = fun(D, w, **kwargs)
        x = pinv(A).dot(b + r)
        return x

    @staticmethod
    def L1OptLinProg(D: np.ndarray, w: np.ndarray) -> np.ndarray:
        [_, col] = np.shape(D)
        t = np.ones([2 * col, 1])
        Phi = np.hstack([D, -D])
        bounds = [(0, None) for _ in range(2 * col)]
        r_opt = linprog(t, A_eq=Phi, b_eq=w, bounds=bounds, method='highs')['x']
        r = r_opt[:col] - r_opt[col:]
        return r.reshape(-1, 1)

    def L1OptGPSR(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        lam = kwargs.get('lam', 1e-8)
        tol = kwargs.get('tol', 1e-6)
        max_iter = kwargs.get('max_iter', 10000)
        [_, col] = np.shape(D)
        alpha, alpha_min, alpha_max = 1.0, 1e-30, 1e+30
        r, u, v = [np.zeros([col, 1]) for _ in range(3)]
        mu = D.dot(r)
        iter = 0
        while iter < max_iter:
            grad_u = D.T.dot(D.dot(r) - w) + lam
            grad_v = -grad_u + 2.0 * lam
            du = np.maximum(u - alpha * grad_u, 0.0) - u
            dv = np.maximum(v - alpha * grad_v, 0.0) - v
            dr = du - dv
            gamma = norm(D.dot(dr), 2)**2
            beta_0 = -(grad_u.T.dot(du) + grad_v.T.dot(dv)) / (gamma + self.real_min)
            beta = min(beta_0, 1)
            u_improve = u + beta * du
            v_improve = v + beta * dv
            y = np.minimum(u_improve, v_improve)
            u = u_improve - y
            v = v_improve - y
            r = u - v
            delta = du.T.dot(du) + dv.T.dot(dv)
            if gamma <= 0:
                alpha = alpha_max
            else:
                alpha = min(alpha_max, max(alpha_min, delta / (gamma + self.real_min)))
            mu = mu + beta * D.dot(dr)
            iter += 1
            if norm(dr) / norm(r) <= tol:
                break
        print("Iteration for {:d} times.".format(iter))
        return r.reshape(-1, 1)

    def L1OptTNIPM(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        lam = kwargs.get('lam', 1e-8)
        tol = kwargs.get('tol', 1e-6)
        max_iter = kwargs.get('max_iter', 50)
        [_, col] = np.shape(D)
        mu, alpha, beta = 2, 0.01, 0.5
        r, u = np.zeros([col, 1]), np.ones([col, 1])
        f = np.vstack([r - u, -r - u])
        df = np.zeros([2 * col, 1])
        s, d_obj = np.inf, -np.inf
        t = min(max(1.0, 1.0 / lam), 2 * col / tol)
        iter = 0
        while iter < max_iter:
            z = D.dot(r) - w
            nu = z
            maxDtv = norm(D.T.dot(nu), np.inf)
            if maxDtv > lam:
                nu = nu * lam / maxDtv
            p_obj = 0.5 * z.T.dot(z) + lam * norm(r, 1)
            d_obj = max(-0.5 * nu.T.dot(nu) - nu.T.dot(w), d_obj)
            gap = p_obj - d_obj
            if gap / d_obj < tol:
                return r.reshape(-1, 1)
            if s >= 0.5:
                t = max(mu * min(2 * col / gap, t), t) + self.real_min
            q1 = 1.0 / (u + r)
            q2 = 1.0 / (u - r)
            grad_f = np.vstack([D.T.dot(z) - (q1 - q2) / t, lam - (q1 + q2) / t])
            B1 = np.diag((q1**2 + q2**2).flatten()) / t
            B2 = np.diag((q1**2 - q2**2).flatten()) / t
            H = np.vstack([np.hstack([D.T.dot(D) + B1, B2]),
                           np.hstack([B2, B1])])
            P = np.vstack([np.hstack([np.eye(col) + B1, B2]),
                           np.hstack([B2, B1])])
            pcg_tol = min(0.1, tol * gap / min(1, norm(grad_f)))
            df, exit_code = cg(H, -grad_f, M=P, x0=df, tol=pcg_tol, maxiter=5000)
            df = df.reshape(-1, 1)
            dr = df[:col]
            du = df[col:]
            F = 0.5 * z.T.dot(z) + lam * np.sum(u) - np.sum(np.log(-f)) / t
            gdf = grad_f.T.dot(df)
            s = 1.0
            while True:
                r_improve = r + s * dr
                u_improve = u + s * du
                f_improve = np.vstack([r_improve - u_improve, -r_improve - u_improve])
                if np.max(f_improve) < 0:
                    z_improve = D.dot(r_improve) - w
                    F_ = 0.5 * z_improve.T.dot(z_improve) + lam * np.sum(u_improve) - np.sum(np.log(-f_improve)) / t
                    if F_ - F <= alpha * s * gdf:
                        break
                s *= beta
            r, u, f = r_improve, u_improve, f_improve
            iter += 1
        print("Iteration for {:d} times.".format(iter))
        return r.reshape(-1, 1)

    def L1OptHomotopy(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        lam = kwargs.get('lam', 1e-8)
        [_, col] = np.shape(D)
        r, z = np.zeros([col, 1]), np.zeros([col, 1])
        p = -D.T.dot(w)
        [p_max, primal_support] = self.search_max(np.abs(p))
        primal_support = np.array([primal_support])
        z[primal_support] = -np.sign(p[primal_support])
        p[primal_support] = p_max * np.sign(p[primal_support])
        B = D[:, primal_support].T.dot(D[:, primal_support])
        while True:
            r_k = r
            gamma = primal_support
            v = np.zeros([col, 1])
            v[gamma] = pinv(B).dot(z[gamma])
            dk = D.T.dot(D).dot(v)
            [delta, i_delta, i_shk, flag] = self.__CalcStepHomotopy(gamma, gamma, r_k, v, p, dk, p_max)
            r = r_k + delta * v
            p = p + delta * dk
            if (p_max - delta) <= lam:
                r = r_k + (p_max - lam) * v
                break
            p_max -= delta
            if flag == 1:
                L = len(gamma)
                idx = np.where(gamma == i_shk)[0][0]
                gamma[idx] = gamma[L - 1]
                gamma[L - 1] = i_shk
                primal_support = gamma[:L - 1]
                B = self.swap_rows(B, idx, L - 1)
                B = self.swap_cols(B, idx, L - 1)
                B = B[:L - 1, :L - 1]
                r[i_shk] = 0
            else:
                primal_support = np.concatenate([primal_support, np.array([i_delta])])
                C = D[:, gamma].T.dot(D[:, i_delta]).reshape(-1, 1)
                right_bottom_element = np.atleast_2d(D[:, i_delta].T.dot(D[:, i_delta]))
                B = np.vstack([np.hstack([B, C]),
                               np.hstack([C.T, right_bottom_element])])
                r[i_delta] = 0
                gamma = primal_support
            z = np.zeros([col, 1])
            z[primal_support] = -np.sign(p[primal_support])
            p[gamma] = p_max * np.sign(p[gamma])
        return r.reshape(-1, 1)

    def __CalcStepHomotopy(self, gamma_r, gamma_lam, r_k, v, p, dk, tol) -> list:
        col = p.shape[0]
        gamma_c = np.array(list(set(np.arange(col)) - set(gamma_lam)))
        gamma_c = np.sort(gamma_c)
        Delta = (tol - p[gamma_c]) / (1 + dk[gamma_c])
        idx1 = np.where(Delta > 0)[0]
        if np.sum(idx1) == 0:
            delta_1 = np.inf
            i_delta1 = np.nan
        else:
            [delta_1, i_delta1] = self.search_min(Delta[idx1])
        Delta = (tol + p[gamma_c]) / (1 - dk[gamma_c])
        idx2 = np.where(Delta > 0)[0]
        if np.sum(idx2) == 0:
            delta_2 = np.inf
            i_delta2 = np.nan
        else:
            [delta_2, i_delta2] = self.search_min(Delta[idx2])
        if delta_1 > delta_2:
            delta = delta_2
            i_delta = gamma_c[idx2[i_delta2]]
        else:
            delta = delta_1
            i_delta = gamma_c[idx1[i_delta1]]
        Delta = -r_k[gamma_r] / v[gamma_r]
        idx3 = np.where(Delta > 0)[0]
        [delta_3, i_delta3] = self.search_min(Delta[idx3])
        if i_delta3 and delta_3 <= delta:
            flag = 1
            delta = delta_3
            i_shk = gamma_r[idx3[i_delta3]]
        else:
            flag = 0
            i_shk = None
        return [delta, i_delta, i_shk, flag]

    def L1OptIST(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        lam = kwargs.get("lam", 1e-8)
        tol = kwargs.get("tol", 1e-5)
        max_iter = kwargs.get("max_iter", 10000)
        [_, col] = D.shape
        alpha_min = 1e-30
        alpha_max = 1e30
        r = np.zeros([col, 1])
        s = D.dot(r) - w
        alpha = 1
        f = 0.5 * s.T.dot(s) + lam * norm(r, 1)
        iter = 0
        while iter < max_iter:
            grad = D.T.dot(s)
            r_prev, f_prev, s_prev = r, f, s
            r = self.__soft(r_prev - grad / alpha, lam / alpha)
            dr = r - r_prev
            z = D.dot(dr)
            s = s_prev + z
            f = 0.5 * s.T.dot(s) + lam * norm(r, 1)
            delta = dr.T.dot(dr)
            gamma = z.T.dot(z)
            alpha = min(alpha_max, max(alpha_min, gamma / (delta + self.real_min)))
            iter += 1
            if np.abs(f - f_prev) / f_prev <= tol:
                break
        print("Iteration for {:d} times.".format(iter))
        return r.reshape(-1, 1)

    def __soft(self, vec, a):
        return np.sign(vec) * np.maximum(np.abs(vec) - a, 0.0)

    def L1OptADM(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        eps = kwargs.get("eps", 1e-8)
        max_iter = kwargs.get("max_iter", 10000)
        [row, col] = D.shape
        zeta = 1.618
        mu = np.mean(np.abs(w)) + self.real_min
        r = D.T.dot(w)
        z, y, g = np.zeros([col, 1]), np.zeros([row, 1]), np.zeros([col, 1])
        s = D.dot(g - z + r / mu) - w / mu
        alpha = s.T.dot(s) / s.T.dot(D).dot(D.T).dot(s)
        iter = 0
        while iter < max_iter:
            s = D.dot(g - z + r / mu) - w / mu
            y = y - alpha * s
            g = D.T.dot(y)
            z = g + r / mu
            idx = np.abs(z) > 1
            z[idx] = np.sign(z[idx])
            r = r + zeta * mu * (g - z)
            iter += 1
            if norm(D.dot(r) - w) / norm(w) <= eps:
                break
        print("Iteration for {:d} times.".format(iter))
        return r.reshape(-1, 1)

    def L1OptPOB(self, D: np.ndarray, w: np.ndarray, **kwargs) -> np.ndarray:
        eps = kwargs.get("eps", 1e-8)
        max_iter = kwargs.get("max_iter", 10000)
        [row, col] = D.shape
        tau = 0.02
        mu = 0.999 * tau / norm(D)**2
        y, r = np.zeros([row, 1]), np.zeros([col, 1])
        z = y - (D.dot(r) - w)
        iter = 0
        while iter < max_iter:
            s = r
            t = s - mu / tau * D.T.dot(2 * y - z)
            r = self.__soft(t, 1 / tau)
            iter += 1
            if norm(r - s) / (norm(s) + self.real_min) < 1e-6:
                break
            z = y
            t = D.dot(r) + z - w
            if norm(t) <= eps:
                y = np.zeros([row, 1])
            else:
                y = (1 - eps / norm(t)) * t
        print("Iteration for {:d} times.".format(iter))
        return r.reshape(-1, 1)


if __name__ == '__main__':
    m, n = 2**8, 2**7
    A = np.random.randn(m, n)
    xx = np.random.randn(n, 1)
    noise = 0.5 * L1NormApproxSolver.sparse_rand(m, 1, 0.05)
    # noise = 0.5 * np.random.randn(m, 1)
    b = A.dot(xx) + noise
    l1solver = L1NormApproxSolver(A, b)
    fun_map = ["LINPROG", "GPSR", "TNIPM", "HOMOTOPY", "IST", "ADM", "POB"]
    for f in fun_map:
        xx_ = l1solver.L1ApproxViaMinREV(f)
        print(np.linalg.norm(xx - xx_) / np.linalg.norm(xx))
