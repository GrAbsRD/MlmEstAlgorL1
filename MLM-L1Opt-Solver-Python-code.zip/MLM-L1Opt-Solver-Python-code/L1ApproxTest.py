#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  
#  Authors: Zhi-Qiang Feng and Hong-Yan Zhang, Hainan Normal University
#    email: z.q.feng@foxmail.com,  hongyan@hainnu.edu.cn  


import numpy as np
from L1NormApproxSolver import L1NormApproxSolver

A = np.array([[2, -1, -1],
              [1, -1, 1],
              [1, 1, 1],
              [-1, 2, -1],
              [2, 3, 0]])
b = np.array([[3], [2], [9], [5], [8]])

l1solver = L1NormApproxSolver(A, b)
x = l1solver.L1ApproxPerturbationCBS(0.01)
print(np.linalg.norm(A.dot(x) - b, 1))
